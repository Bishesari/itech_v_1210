<div class="relative mb-6 w-full">
    <flux:heading size="xl" level="1">{{ __('تنظیمات حساب کاربری') }}</flux:heading>
    <flux:subheading size="lg" class="mb-6">{{ __('حساب کاربری و پروفایل خود را مدیریت کنید.') }}</flux:subheading>
    <flux:separator />
</div>
