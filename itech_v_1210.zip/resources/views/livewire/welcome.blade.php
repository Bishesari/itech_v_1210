<?php

use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;
use Livewire\Volt\Component;


new
#[Layout('components.layouts.public')]
#[Title('Login')]
class extends Component {
    //
}; ?>

<div>

</div>
