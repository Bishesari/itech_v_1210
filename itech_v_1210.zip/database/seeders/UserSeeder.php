<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        User::create([
            'user_name' => 'Yasser.Bishesari',
            'password' => '404Institute$#',
        ]);

        User::create([
            'user_name' => 'test',
            'password' => 'test',
        ]);

    }
}
