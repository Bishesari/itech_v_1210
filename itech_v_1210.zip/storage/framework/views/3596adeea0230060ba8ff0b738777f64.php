<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<!-- Metaها از متدهای کامپوننت -->
<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($this)): ?>
    <meta name="description" content="<?php echo e($this->metaDescription()); ?>">
    <meta name="keywords" content="<?php echo e($this->metaKeywords()); ?>">
<?php else: ?>
    <meta name="description" content="توضیحات پیش‌فرض">
    <meta name="keywords" content="">
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<title><?php echo e($title ?? config('app.name')); ?></title>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
<?php echo app('flux')->fluxAppearance(); ?>

<?php /**PATH D:\lara_prjs\itech_v_1210\resources\views/partials/head.blade.php ENDPATH**/ ?>