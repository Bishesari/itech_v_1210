<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['name'=>'', 'label'=>'', 'readonly'=>'']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['name'=>'', 'label'=>'', 'readonly'=>'']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<!-- floating input (RTL) -->
<div class="relative">
    <input id="<?php echo e($name); ?>" name="<?php echo e($name); ?>" wire:model="<?php echo e($name); ?>" <?php echo e($readonly); ?> placeholder=" " <?php echo e($attributes->merge(['class' => 'peer w-full border-2 rounded-lg
     border-stone-300 dark:border-stone-700 pt-3.5 pb-2.5 focus:outline-none focus:border-blue-700 transition text-center text-stone-600 dark:text-stone-400'])); ?>/>

    <label for="<?php echo e($name); ?>" class="absolute right-3 top-3 transition-all duration-150 text-gray-400 text-base px-2
    peer-focus:-top-2.5 peer-focus:text-sm peer-focus:text-blue-700 dark:peer-focus:text-blue-400 peer-focus:bg-accent-foreground dark:peer-focus:bg-zinc-800
    peer-[:not(:placeholder-shown)]:bg-accent-foreground dark:peer-[:not(:placeholder-shown)]:bg-zinc-800
    peer-[:not(:placeholder-shown)]:-top-2.5
    peer-[:not(:placeholder-shown)]:right-2.5 peer-[:not(:placeholder-shown)]:text-sm

    "><?php echo e($label); ?></label>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="mt-0.5 text-sm text-red-600 dark:text-red-400 text-center"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div>
<?php /**PATH D:\lara_prjs\itech_v_1210\resources\views/components/my/flt_lbl.blade.php ENDPATH**/ ?>