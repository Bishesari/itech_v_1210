<?php

use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;
use Livewire\Volt\Component;

?>

<div>

</div><?php /**PATH D:\lara_prjs\itech_v_1210\resources\views\livewire/welcome.blade.php ENDPATH**/ ?>